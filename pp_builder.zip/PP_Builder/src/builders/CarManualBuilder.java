package builders;

import cars.CarType;
import cars.Engine;
import cars.GPSNavigator;
import cars.Manual;
import cars.Transmission;
import cars.TripComputer;

/**
 * Diferentemente de outros padrões criacionais, o Builder consegue construir produtos
 * não relacionados, que não possuem uma interface em comum.
 * 
 * Neste caso, é construído um manual para um carro, envolvendo as mesmas etapas da
 * construção de um carro. Isso permite a produção de manuais para modelos específicos
 * de carros configurados com diferentes recursos. 
 */

public class CarManualBuilder implements Builder{
	private CarType type;
	private int seats;
	private Engine engine;
	private Transmission transmission;
	private TripComputer tripComputer;
	private GPSNavigator gpsNavigator;

	@Override
	public void setCarType(CarType type) {
		this.type = type;
	}
	
	@Override
	public void setSeats(int seats) {
		this.seats = seats;
	}
	
	@Override
	public void setEngine(Engine engine) {
		this.engine = engine;
	}
	
	@Override
	public void setTransmission(Transmission transmission) {
		this.transmission = transmission;
	}
	
	@Override
	public void setTripComputer(TripComputer tripComputer) {
		this.tripComputer = tripComputer;
	}
	
	@Override
	public void setGPSNavigator(GPSNavigator gpsNavigator) {
		this.gpsNavigator = gpsNavigator;
	}
	
	public Manual getResult() {
		return new Manual(type, seats, engine, transmission, tripComputer, gpsNavigator);
	}
}

import builders.CarBuilder;
import builders.CarManualBuilder;
import cars.Car;
import cars.Manual;
import director.Director;

public class Demo {
	public static void main(String [] args) {
		Director director = new Director();
		
		// O Diretor recebe o builder do cliente. A aplicação sabe qual o melhor
		// builder a ser usado para produzir um produto específico.
		CarBuilder builder = new CarBuilder();
		director.constructSportsCar(builder);
		
		// O produto final é recebido do builder, já que o diretor não está
		// ciente e não depende de builders e produtos concretos.
		Car car = builder.getResult();
		System.out.println("Car built:\n" + car.getCarType());
		
		CarManualBuilder manualBuilder = new CarManualBuilder();
		
		// O diretor pode saber como construir diversos tipos de carros.
		director.constructSportsCar(manualBuilder);
		Manual carManual = manualBuilder.getResult();
		System.out.println("\nCar manual built:\n" + carManual.print());
	}
}
